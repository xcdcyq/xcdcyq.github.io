# -*- coding: utf-8 -*-
"""
Created on Fri Sep 20 21:10:19 2024

@author: yq1215
"""

import pygame
import sys
import math
import time
import random
from random import randint
from pygame.locals import *
import winsound

class Cloud(pygame.sprite.Sprite):
    def __init__(self,pos,group):
        super().__init__(group)
        self.image = pygame.image.load('graphics/cloud.png').convert_alpha()
        self.rect = self.image.get_rect(topleft = pos)

#定义Bullet（子弹）类
class Bullet(pygame.sprite.Sprite):
    def __init__(self, pos, angle, damage, group, player):
        super().__init__(group)
        pygame.sprite.Sprite.__init__(self)
        #self.image = self.image1 = pygame.Surface((10, 1))  # 用一个简单的矩形代替子弹图片  
        #self.image.fill((255, 255, 0))  # 设置为黄色  
        self.image = self.image1 = pygame.image.load("graphics/bullet.png")
        self.rect = self.image.get_rect(center = pos) 
        self.angle = angle
        self.image = pygame.transform.rotate(self.image1,self.angle)
        self.rect = self.image.get_rect(center=self.rect.center)
        self.vel = 25
        self.initial_pos_x = pos[0]    #存储诞生的初始位置留作备用
        self.initial_pos_y = pos[1]
        self.damage = damage
        self.start_time = time.time()
        
    def update(self,group): #子弹移动方法
        self.rect.x += self.vel*math.cos(math.radians(self.angle))
        self.rect.y -= self.vel*math.sin(math.radians(self.angle))
        
    def distance_2(self):   # 检测自身是否在玩家可视范围内
        if(self.rect.left < 1800
           or self.rect.right > 0
           or self.rect.top <1200
           or self.rect.bottom >0):
            return True
        else:
            return False
        
    def judge(self,group):
        if time.time() - self.start_time < 3:
            if not self.distance_2():
                if self.rect.bottom - group.ground_rect.y < 0 - 1200:
                    self.rect.bottom = group.ground_rect.y + 3200
                            
                if self.rect.top - group.ground_rect.y > 3200 + 1200:
                    self.rect.top = group.ground_rect.y
                    
                if self.rect.right - group.ground_rect.x < 0 - 1800:
                    self.rect.right = group.ground_rect.x + 3648
                    
                if self.rect.left - group.ground_rect.x > 3648 + 1800:
                    self.rect.left = group.ground_rect.x
            else:
                if player.rect.bottom - group.ground_rect.y < 0 - 600:
                    self.rect.bottom = group.ground_rect.y + 3200 + (self.rect.bottom - player.rect.bottom)
                if player.rect.top - group.ground_rect.y > 3200 + 600:
                    self.rect.top = group.ground_rect.y - 600 + (self.rect.top - player.rect.top)
                if player.rect.right - group.ground_rect.x < 0 - 900:
                    self.rect.right = group.ground_rect.x + 3648 + 900 + (self.rect.right - player.rect.right)
                if player.rect.left - group.ground_rect.x > 3648 + 900:
                    self.rect.left = group.ground_rect.x - 900 + (self.rect.left - player.rect.left)
            return False
        else:
            return True
    # def judge(self,group):    #判断子弹是否到时间（并进行穿越界面操作）

    #     if time.time() - self.start_time < 3:
    #         if self.rect.bottom - group.ground_rect.y < 0 - 1200:
    #             self.rect.bottom = group.ground_rect.y + 3200 + 600
                
    #         if self.rect.top - group.ground_rect.y > 3200 + 1200:
    #             self.rect.top = group.ground_rect.y - 600
                
    #         if self.rect.right - group.ground_rect.x < 0 - 1400:
    #             self.rect.right = group.ground_rect.x + 3648 + 700
                
    #         if self.rect.left - group.ground_rect.x > 3648 + 1400:
    #             self.rect.left = group.ground_rect.x - 700
                
    #         return False
    #     else:
    #         return True
        
    def judge1(self, enemy_list):   #判断子弹是否击中敌机
        flag = False
        for enemy in enemy_list:
            if self.rect.colliderect(enemy.rect):  # 先检查边界框是否相交
                if pygame.sprite.collide_mask(self, enemy):
                    winsound.Beep(500,1)
                    enemy.health -= self.damage
                    flag = True
        return flag

class Player(pygame.sprite.Sprite):
    def __init__(self, pos, max_health, max_bullet, all_bullet, group):
        super().__init__(group)
        self.image = pygame.image.load('graphics/歼16.png').convert_alpha()
        self.image = pygame.transform.scale(self.image,(72,48))
        self.image1 = self.image
        self.rect = self.image.get_rect(center = pos)
        self.initial_pos_x = pos[0]
        self.initial_pos_y = pos[1]
        self.score = 0       #当前得分
        
        self.max_speed = 12
        self.min_speed = 8
        self.now_speed = self.min_speed
        self.acceleration = 0.5
        self.vel_x = 0 
        self.vel_y = 0 
        self.angular_speed = 1  #角速度
        self.angular_sharp_speed = 3
        self.current_angle = 0 
        
        self.max_health = max_health  
        self.health = max_health  # 初始生命值等于最大生命值
        self.health_bar = HealthBar(screen, 300, 80, 200, 20, max_health)  # 创建血条对象
        
        self.bullet_list = []   #存储发射出去的子弹对象引用 
        self.bullet_clip = max_bullet  # 弹夹容量  
        self.bullet_all = all_bullet  # 携带的所有子弹数量 
        self.bullets_in_clip = self.bullet_clip  # 当前弹夹内子弹数量  
        self.bullet_remanent = self.bullet_all  # 当前剩余弹药数量
        self.reloading = False  # 是否正在填充子弹  
        self.reload_start_time = 0  # 开始填充子弹的时间点  
        self.reload_time = 5  # 填充子弹所需时间 
        self.bullet_clip_bar = HealthBar(screen, 300, 105, 200, 20, max_bullet)  #创建血条对象显示弹夹条
        self.bullet_all_bar = HealthBar(screen, 350, 130, 200, 20, all_bullet)  #创建血条对象显示剩余所有弹药
        
    def move(self,group):
        keys = pygame.key.get_pressed()
        
        # if keys[K_w] and self.rect.top - group.ground_rect.y <= 0 - 600:
        #     # self.vel_y = 0 
        #     self.rect.top = group.ground_rect.y + 3200 + 600
        # elif keys[K_w] and self.rect.top - group.ground_rect.y > 0 - 600:
        #     if self.vel_y > -self.max_speed:
        #         self.vel_y -= self.acceleration
        # elif self.vel_y < 0 :
        #     self.vel_y += self.acceleration
        #     if self.vel_y > -self.acceleration:
        #         self.vel_y = 0 
                
        # if keys[K_s] and self.rect.bottom - group.ground_rect.y >= 3200 + 600:
        #     # self.vel_y = 0
        #     self.rect.bottom = group.ground_rect.y - 600
        # elif keys[K_s] and self.rect.bottom - group.ground_rect.y < 3200 + 600:  
        #     if self.vel_y < self.max_speed:  
        #         self.vel_y += self.acceleration  
        # elif self.vel_y > 0:  
        #     self.vel_y -= self.acceleration  
        #     if self.vel_y < self.acceleration:  
        #         self.vel_y = 0 

        # if keys[K_a] and self.rect.left - group.ground_rect.x <= 0 - 700:
        #     # self.vel_x = 0
        #     self.rect.left = group.ground_rect.x + 3648 + 700
        # elif keys[K_a] and self.rect.left - group.ground_rect.x > 0 - 700:  
        #     if self.vel_x > -self.max_speed:  
        #         self.vel_x -= self.acceleration  
        # elif self.vel_x < 0:  
        #     self.vel_x += self.acceleration  
        #     if self.vel_x > -self.acceleration:  
        #         self.vel_x = 0  

        # if keys[K_d] and self.rect.right - group.ground_rect.x >= 3648 + 700:
        #     # self.vel_x = 0
        #     self.rect.right = group.ground_rect.x - 700
        # elif keys[K_d] and self.rect.right - group.ground_rect.x < 3648 + 700:  
        #     if self.vel_x < self.max_speed:  
        #         self.vel_x += self.acceleration  
        # elif self.vel_x > 0:  
        #     self.vel_x -= self.acceleration  
        #     if self.vel_x < self.acceleration:  
        #         self.vel_x = 0
        
        if keys[K_w] and self.now_speed < self.max_speed:
            self.now_speed += self.acceleration
        elif not keys[K_w] and self.now_speed > self.min_speed:
            self.now_speed -= self.acceleration
            
        self.vel_x = self.now_speed * math.cos(math.radians(self.current_angle))
        self.vel_y = self.now_speed * math.sin(math.radians(self.current_angle))
        #穿越边界处理
        if self.rect.bottom - group.ground_rect.y < 0 - 600 - 1000:
            self.rect.bottom = group.ground_rect.y + 3200 + 600 + 1000
        if self.rect.top - group.ground_rect.y > 3200 + 600 + 1000:
            self.rect.top = group.ground_rect.y - 600 - 1000
        if self.rect.right - group.ground_rect.x < 0 - 900 - 1000:
            self.rect.right = group.ground_rect.x + 3648 + 900 + 1000
        if self.rect.left - group.ground_rect.x > 3648 + 900 + 1000:
            self.rect.left = group.ground_rect.x - 900 - 1000
 
        
    def zhuandong(self):   #转动
    #     mouse_x,mouse_y = pygame.mouse.get_pos()
    #     mouse_x = mouse_x - self.initial_pos_x + self.rect.centerx
    #     mouse_y = mouse_y - self.initial_pos_y + self.rect.centery
        
    #     target_angle = get_angle(self.rect.centerx,self.rect.centery,mouse_x,mouse_y)
    #     self.current_angle = rotate_towards_mouse(self.current_angle,target_angle,self.angular_speed)
    #     self.image = rotated_img = pygame.transform.rotate(self.image1,self.current_angle)
    #     self.rect = new_rect = rotated_img.get_rect(center=self.rect.center)
        keys = pygame.key.get_pressed()
        
        if keys[K_a]:
            self.current_angle += self.angular_speed
        if keys[K_d]:
            self.current_angle -= self.angular_speed
        if keys[K_q]:
            self.current_angle += self.angular_sharp_speed
        if keys[K_e]:
            self.current_angle -= self.angular_sharp_speed
        if self.current_angle > 360:
            self.current_angle -= 360
        if self.current_angle < 0:
            self.current_angle += 360
        self.image = rotated_img = pygame.transform.rotate(self.image1,self.current_angle)
        self.rect = new_rect = rotated_img.get_rect(center=self.rect.center)
        
        
    def fire(self,group):   #存储发射子弹的方法
        if not self.reloading and self.bullets_in_clip > 0 : 
            winsound.Beep(5000,1)
            self.bullet_list.append(Bullet((self.rect.centerx + 3*math.cos(math.radians((self.current_angle + 90)%360)) + 25*math.cos(math.radians(self.current_angle)), 
                                           self.rect.centery - 3*math.sin(math.radians((self.current_angle + 90)%360)) - 25*math.sin(math.radians(self.current_angle))), 
                                           self.current_angle, 1, group, self)) #将发射的子弹对象存储到bullet_list中
            self.bullet_list.append(Bullet((self.rect.centerx + 3*math.cos(math.radians((self.current_angle - 90)%360)) + 25*math.cos(math.radians(self.current_angle)), 
                                           self.rect.centery - 3*math.sin(math.radians((self.current_angle - 90)%360)) - 25*math.sin(math.radians(self.current_angle))), 
                                           self.current_angle, 1, group, self)) #将发射的子弹对象存储到bullet_list中
            self.bullets_in_clip -= 2  
            self.bullet_remanent -= 2 
            if self.bullets_in_clip == 0 :  
                self.start_reload()
            
    def dellet_bullet(self, enemy_list, enemy_out, group):   #从bullet_list中删除不需显示的子弹
        # 首先处理子弹的显示和移动  
        for bullet in self.bullet_list:
            if bullet.judge(group) or bullet.judge1(enemy_list):#判断子弹是否越界或触碰敌机
                self.bullet_list.remove(bullet) #将子弹从bullet_list中删除 
            for enemy in enemy_list:
                if enemy.health <= 0:  
                    enemy_out.append(enemy)
                    enemy_list.remove(enemy)
                    self.score += 4            #用子弹摧毁敌机才会加分，撞毁不加分
            
    def start_reload(self):    #开始装弹的时间
        self.reloading = True  
        self.reload_start_time = time.time()  

    def update_reload(self):   #装弹
        if self.reloading:  
            current_time = time.time()  
            if current_time - self.reload_start_time >= self.reload_time:  
                self.bullets_in_clip = self.bullet_clip  
                self.reloading = False 
                
    def take_damage(self, damage):    #受到伤害
        self.health -= damage  
        if self.health < 0:  
            self.health = 0  # 生命值不会小于0  
  
    def heal(self, heal_amount):      #治愈回血
        self.health += heal_amount  
        if self.health > self.max_health:  
            self.health = self.max_health  # 生命值不会超过最大生命值
            
    def collision(self, enemy_list, enemy_out):   #判断是否与敌机发生碰撞
        flag = False
        for enemy in enemy_list:
            if self.rect.colliderect(enemy.rect):
                if pygame.sprite.collide_mask(self, enemy):
                    winsound.Beep(300,2)
                    self.take_damage(enemy.health)
                    enemy.health = 0
                    enemy_out.append(enemy)
                    enemy_list.remove(enemy)
                    flag = True
        return flag
        
    def update(self,group):
        self.move(group)
        self.zhuandong()
        self.dellet_bullet(Enemy_list,enemy_out,group)
        if self.bullet_remanent > 0 :
            self.update_reload()                 # 弹夹填充
        
        self.rect.centerx += int(self.vel_x)
        self.rect.centery -= int(self.vel_y)
        

#定义Enemy（敌机）类
class Enemy(pygame.sprite.Sprite):
    def __init__(self, pos, image, max_health, group, player):
        super().__init__(group)
        pygame.sprite.Sprite.__init__(self)
        self.screen = screen
        self.image = image.convert_alpha()
        self.image1 = self.image  #保留原图
        self.rect = self.image.get_rect()  
        self.rect.topleft = pos

        self.acceleration = 0.2  
        self.max_speed = 6   
        # 初始随机速度
        self.vel_x = random.uniform(-6, -3) if random.random() < 0.5 else random.uniform(3, 6)    
        self.vel_y = random.uniform(-6, -3) if random.random() < 0.5 else random.uniform(3, 6)
        
        self.max_health = max_health  
        self.health = max_health  # 初始生命值等于最大生命值
        self.move_choice = random.random()  # 随机选择运动方式
        
    def distance_1(self):   # 检测自身是否在玩家的圆形雷达领域内
        l = math.sqrt((self.rect.centerx - 900)**2 + (self.rect.centery - 600)**2)
        if (l <= 500):
            return True
        else:
            return False
        
    def distance_2(self):   # 检测自身是否在玩家可视范围内
        if(self.rect.left < 1800
           or self.rect.right > 0
           or self.rect.top <1200
           or self.rect.bottom >0):
            return True
        else:
            return False
        
    def move1(self,group):
        # 边界检测
        if (self.rect.left - group.ground_rect.x <= 0
            or self.rect.right - group.ground_rect.x >= 3648):  
            self.vel_x = -self.vel_x * random.uniform(0.8, 1.2)  # 随机调整速度大小  
        if (self.rect.top - group.ground_rect.y <= 0
            or self.rect.bottom - group.ground_rect.y >= 3200):  
            self.vel_y = -self.vel_y * random.uniform(0.8, 1.2)  

        # if not self.distance_2():
        #     if self.rect.bottom - group.ground_rect.y < 0 - 1200:
        #         self.rect.bottom = group.ground_rect.y + 3200
                
        #     if self.rect.top - group.ground_rect.y > 3200 + 1200:
        #         self.rect.top = group.ground_rect.y
                
        #     if self.rect.right - group.ground_rect.x < 0 - 1800:
        #         self.rect.right = group.ground_rect.x + 3648
                    
        #     if self.rect.left - group.ground_rect.x > 3648 + 1800:
        #         self.rect.left = group.ground_rect.x
        # else:
        #     if player.rect.bottom - group.ground_rect.y < 0 - 600:
        #         self.rect.bottom = group.ground_rect.y + 3200 + (self.rect.bottom - player.rect.bottom)
        #     if player.rect.top - group.ground_rect.y > 3200 + 600:
        #         self.rect.top = group.ground_rect.y - 600 + (self.rect.top - player.rect.top)
        #     if player.rect.right - group.ground_rect.x < 0 - 900:
        #         self.rect.right = group.ground_rect.x + 3648 + 900 + (self.rect.right - player.rect.right)
        #     if player.rect.left - group.ground_rect.x > 3648 + 900:
        #         self.rect.left = group.ground_rect.x - 900 + (self.rect.left - player.rect.left)
        
        # 随机方向变化（非边界时）  
        if random.random() < 0.02:  # 2% 的概率改变方向 和 速率 
            self.vel_x = random.uniform(-6, -3) if random.random() < 0.5 else random.uniform(3, 6)  
            self.vel_y = random.uniform(-6, -3) if random.random() < 0.5 else random.uniform(3, 6)  
        
        # # 做测试时固定移动方式
        # self.vel_x = self.max_speed
        # self.vel_y = 0
        
        # 更新位置  
        self.rect.left += self.vel_x 
        self.rect.top -= self.vel_y  
        
    def move2(self, group):
        
        # 边界检测  
        if (self.rect.left - group.ground_rect.x <= 0 
            or self.rect.right - group.ground_rect.x >= 3648):  
            self.vel_x = -self.vel_x * random.uniform(0.8, 1.2)  # 随机调整速度大小  
        if (self.rect.top - group.ground_rect.y <= 0 
            or self.rect.bottom - group.ground_rect.y >= 3200):  
            self.vel_y = -self.vel_y * random.uniform(0.8, 1.2) 
            
        for target in group.sprites():
            if isinstance(target, Player):                
                angel = get_angle(target.rect.centerx, target.rect.centery,self.rect.centerx,self.rect.centery)
                self.vel_x = self.max_speed*math.cos(math.radians(angel))
                self.vel_y = self.max_speed*math.sin(math.radians(angel))
                # # 边界检测  
                # if (self.rect.left - group.ground_rect.x <= 0 
                #     or self.rect.right - group.ground_rect.x >= 3648):  
                #     self.vel_x = -self.vel_x * random.uniform(0.8, 1.2)  # 随机调整速度大小  
                # if (self.rect.top - group.ground_rect.y <= 0 
                #     or self.rect.bottom - group.ground_rect.y >= 3200):  
                #     self.vel_y = -self.vel_y * random.uniform(0.8, 1.2) 
        
        # 更新位置  
        self.rect.left += self.vel_x 
        self.rect.top -= self.vel_y 
        
    def update(self,group):
        # self.move1(group) if(self.rect.left - group.ground_rect.x <= 0 + 500 
        #                      or self.rect.right - group.ground_rect.x >= 3648 - 500
        #                      or self.rect.top - group.ground_rect.y <= 0 + 500 
        #                      or self.rect.bottom - group.ground_rect.y >= 3200 - 500
        #                      )  else self.move2(group)
        if  (self.rect.left - group.ground_rect.x >= 0 + 800 
            and self.rect.right - group.ground_rect.x <= 3648 - 800
            and self.rect.top - group.ground_rect.y >= 0 + 800 
            and self.rect.bottom - group.ground_rect.y <= 3200 - 800):
            if self.distance_1():
                self.move2(group)
            else:
                self.move1(group)
        else:
            self.move1(group)
            
class CameraGroup(pygame.sprite.Group):
    def __init__(self):
        super().__init__()
        self.display_surface = pygame.display.get_surface()
        
        # camera offset
        self.offset = pygame.math.Vector2()
        self.half_w = self.display_surface.get_size()[0] // 2
        self.half_h = self.display_surface.get_size()[1] // 2     
        
        # ground
        self.ground_surf = pygame.image.load('graphics/ground.png').convert_alpha()
        self.ground_rect = self.ground_surf.get_rect(topleft = (0,0))       
        
		# border setup
        self.border1 = {'left': 800, 'right': 800, 'top': 800, 'bottom': 800}
        l1 = self.border1['left']
        t1 = self.border1['top']
        w1 = self.ground_rect.w  - (self.border1['left'] + self.border1['right'])
        h1 = self.ground_rect.h  - (self.border1['top'] + self.border1['bottom'])
        self.border1_rect = pygame.Rect(l1,t1,w1,h1)
        
        self.border2 = {'left': 0, 'right': 0, 'top': 0, 'bottom': 0}
        l2 = self.border2['left']
        t2 = self.border2['top']
        w2 = self.ground_rect.w  - (self.border2['left'] + self.border2['right'])
        h2 = self.ground_rect.h  - (self.border2['top'] + self.border2['bottom'])
        self.border2_rect = pygame.Rect(l2,t2,w2,h2)
    
    def center_target_camera(self,target):
        self.offset.x = target.rect.centerx - self.half_w
        self.offset.y = target.rect.centery - self.half_h
    
    def custom_draw(self,player):
        
        self.center_target_camera(player)  

        # ground
        ground_offset = self.ground_rect.topleft - self.offset
        self.ground_rect.topleft = ground_offset
        self.display_surface.blit(self.ground_surf,ground_offset)
        
        # 绘制边框
        # pygame.draw.rect(self.ground_surf,'yellow',self.border1_rect,5)
        # pygame.draw.rect(self.ground_surf,'black',self.border2_rect,5)
        # pygame.draw.circle(self.display_surface,'red',(900,600),500,5)
        # active elements
        for sprite in sorted(self.sprites(),key = lambda sprite: sprite.rect.centery):        
            if isinstance(sprite, Cloud):
                offset_pos = sprite.rect.topleft - 1.1*self.offset
                sprite.rect.topleft = offset_pos 
                self.display_surface.blit(sprite.image,offset_pos)
                # pygame.draw.rect(self.display_surface,'yellow',sprite.rect,5)
            elif isinstance(sprite, Enemy):
                if sprite in Enemy_list:
                    offset_pos = sprite.rect.topleft - self.offset
                    sprite.rect.topleft = offset_pos 
                    self.display_surface.blit(sprite.image,offset_pos) 
                    # 创建并实时更新血条对象位置
                    sprite.health_bar = HealthBar(self.display_surface, sprite.rect.left-5, sprite.rect.top-10, 30, 3, sprite.max_health)
                    sprite.health_bar.draw((0,0,0),(0,255,0), sprite.health)
            elif isinstance(sprite, Player):
                offset_pos = sprite.rect.topleft - self.offset
                sprite.rect.topleft = offset_pos 
                # pygame.draw.rect(self.display_surface,'yellow',sprite.rect,5)
                if sprite.health > 0 :
                    self.display_surface.blit(sprite.image,offset_pos)
                    sprite.collision(Enemy_list, enemy_out)          #碰撞检测                            
            elif isinstance(sprite, Bullet):
                if sprite in player.bullet_list:
                    offset_pos = sprite.rect.topleft - self.offset
                    sprite.rect.topleft = offset_pos 
                    self.display_surface.blit(sprite.image,offset_pos)
                    
#血条类
class HealthBar(pygame.sprite.Sprite):  
    def __init__(self, screen, x, y, width, height, max_health):  
        pygame.sprite.Sprite.__init__(self)
        self.screen = screen  
        self.x = x  
        self.y = y  
        self.width = width  
        self.height = height  
        self.max_health = max_health  
  
    def draw(self, color_bottom, color_up, current_health):  
        # 计算血条长度  
        bar_length = (current_health / self.max_health) * self.width  
        # 绘制红色底条  
        pygame.draw.rect(self.screen, color_bottom, (self.x, self.y, self.width, self.height))  
        # 绘制绿色血条  
        pygame.draw.rect(self.screen, color_up, (self.x, self.y, bar_length, self.height)) 
        
#获取角度
def get_angle(x1,y1,x2,y2):
    dx = x2 - x1
    dy = y2 - y1
    return math.degrees(math.atan2(-dy,dx))

#更新当前角度 current_angle
def rotate_towards_mouse(current_angle,target_angle,angular_speed):
    angle_diff = target_angle - current_angle
    if angle_diff > 180:
        angle_diff -= 360
    elif angle_diff < -180:
        angle_diff += 360
    if angle_diff > 0:
        return (current_angle + min(angular_speed,angle_diff)) % 360
    elif angle_diff < 0:
        return (current_angle - min(angular_speed,-angle_diff)) % 360
    else:
        return current_angle

#显示文字
def show_text(surface_handle, pos, text, color, font_bold=False, font_size=13, font_italic=False):
    cur_font = pygame.font.SysFont("宋体",font_size) #获取系统字体
    #cur_font = pygame.font.Font('simhei.ttf',30)
    cur_font.set_bold(font_bold)                     #设置是否加粗
    cur_font.set_italic(font_italic)                 #设置是否斜体
    text_fmt = cur_font.render(text, 1, color)       #设置文字内容
    surface_handle.blit(text_fmt, pos)               #绘制文字
    
# 定义显示文字的函数  
def show_text_with_chinese_font(surface, pos, text, color, font_size=24, font_path='fonts/stxingka.ttf'):  
    font = pygame.font.Font(font_path, font_size)  
    text_surface = font.render(text, True, color)  
    surface.blit(text_surface, pos)
    
# 初始化
pygame.init()
clock = pygame.time.Clock()
pygame.mouse.set_visible(True)  # 显示鼠标
screen = pygame.display.set_mode((1800,1200))
clock = pygame.time.Clock()
pygame.display.set_caption("Space War 1.5")

# 有关游戏时间和状态  
start_time = 0        # 游戏开始时刻
no_pause_time = 0     # 解除暂停的时刻
pause_time = 0        # 暂停的时刻
tmp_time = 0          # 暂停的时长
time_flag = False
elapsed_time = 0      # 游戏进行的时长
game_time = 300       # 游戏规定时长
death_time = None     # 记录阵亡时间
over_time = None      # 记录游戏结束时间
paused = True  # 初始化游戏为暂停状态(True表示暂停状态 False表示非暂停状态)

# 处理敌机对象
enemy_number = 25     # 敌机总数
enemy_out = []        # 被击毁和撞毁的敌机列表  
max_enemy_count = 15  # 当前屏幕最大敌机数量 
Enemy_list = []       # 创建一个空的敌机列表 
frame_count = 0       # 控制敌机对象添加的帧数间隔  
add_enemy_interval = 60  # 每隔6帧添加一个敌机对象

# 设置精灵组camera_group 和 玩家对象player
camera_group = CameraGroup()
player = Player((900,600),50,500,3000, camera_group)

screen.fill('#71ddee')  # 用纯色填充窗口
camera_group.update(camera_group)   #更新精灵组中所有对象
camera_group.custom_draw(player)    #绘制精灵组中所有对象

# 显示文字
text_pos = "欢迎来到太空大战！"
show_text_with_chinese_font(screen, (500, 500), text_pos, (255, 0, 0), 100)
show_text_with_chinese_font(screen, (550, 600), text_pos, (0, 0, 0), 50)
text_pos = "请按下‘C’键以关闭并退出游戏"
show_text_with_chinese_font(screen, (550, 650), text_pos, (0, 0, 0), 50)
text_pos = "作为一名飞行员，你得在地球上的战争中证明自己的实力"
show_text_with_chinese_font(screen, (400, 800), text_pos, (0, 0, 0), 40)
text_pos = "才能加入中国太空军，前往真正的太空作战"
show_text_with_chinese_font(screen, (500, 840), text_pos, (0, 0, 0), 40)

pygame.display.update() #更新屏幕


for i in range(30):
    random_x = randint(0,3684)
    random_y = randint(0,3200)
    Cloud((random_x,random_y),camera_group)
    
while True:
    clock.tick(200) # 每秒不超过600帧的速度运行
    for event in pygame.event.get():
        if event.type == QUIT:
            screen.fill('#71ddee')  # 用纯色填充窗口
            camera_group.display_surface.blit(camera_group.ground_surf,camera_group.ground_rect.topleft)
            text_pos = "后会有期"
            show_text_with_chinese_font(screen, (700, 500), text_pos, (255, 0, 0), 100)
            pygame.display.update() #更新屏幕
            time.sleep(1)
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:  
            if event.key == pygame.K_c: # 按下 "C" 键关闭游戏
                screen.fill('#71ddee')  # 用纯色填充窗口
                camera_group.display_surface.blit(camera_group.ground_surf,camera_group.ground_rect.topleft)
                text_pos = "后会有期"
                show_text_with_chinese_font(screen, (700, 500), text_pos, (255, 0, 0), 100)
                pygame.display.update() #更新屏幕
                time.sleep(1)
                pygame.quit()
                sys.exit()
            if event.key == pygame.K_p:  
                paused = not paused  # 按下 "P" 键时切换暂停状态 
                if paused == True:
                    text_pos = "暂停"
                    show_text_with_chinese_font(screen, (800, 500), text_pos, (255, 0, 0), 100)
                    text_pos = "请按下‘P’键以继续游戏"
                    show_text_with_chinese_font(screen, (600, 600), text_pos, (0, 0, 0), 50)
                    pygame.display.update() #更新屏幕
            if (event.key == pygame.K_o and player.health == 0 or
                event.key == pygame.K_o and len(enemy_out)==enemy_number or
                event.key == pygame.K_o and elapsed_time >= game_time): # 重新开始游戏
                # 重置所有初始化的东西
                Enemy_list.clear()  # 清空敌机列表  
                frame_count = 0  # 重置帧数计数器  
                enemy_out = [] # 重置剩余敌机数量
                camera_group = CameraGroup()
                player = Player((900,600),50,500,3000,camera_group)
                
                start_time = time.time()        # 游戏开始时刻
                no_pause_time = 0     # 解除暂停的时刻
                pause_time = 0        # 暂停的时刻
                tmp_time = 0          # 暂停的时长
                time_flag = False
                elapsed_time = 0      # 游戏进行的时长
                death_time = None        # 记录阵亡时间
                over_time = None      # 记录游戏结束时间
                minutes_elapsed = 0  
                seconds_elapsed = 0 

                
    # 如果游戏没有暂停，则更新时间  
    if not paused and start_time == 0 :  
        start_time = time.time()  
        
    # 如果游戏没有暂停，则更新时间  
    if not paused and time_flag:  
        no_pause_time = time.time()  
        time_flag = not time_flag
    
    if not paused:  # 只有在非暂停状态下才更新游戏逻辑和绘制 

        screen.fill('#71ddee')
        
        camera_group.update(camera_group)   #更新精灵组中所有对象
        camera_group.custom_draw(player)    #绘制精灵组中所有对象
    
        # 随机生成敌机
        frame_count += 1 # 帧数递增
        if (len(enemy_out)+len(Enemy_list)<enemy_number 
            and len(Enemy_list)<max_enemy_count 
            and frame_count % add_enemy_interval==0):  
            # 随机生成敌机的初始位置  
            # x = random.choice([0, 1780])  # 在屏幕左右边缘随机选择 
            random_x = randint(camera_group.ground_rect.centerx-1000,camera_group.ground_rect.centerx+1000)
            random_y = randint(camera_group.ground_rect.centery-1000,camera_group.ground_rect.centery+1000) 
            # 加载敌机图像  
            enemy_image = pygame.image.load("graphics/enemy1.png")  
            # 创建敌机对象  
            enemy = Enemy((random_x,random_y),enemy_image,10,camera_group,player)  
            # 将敌机对象添加到敌机列表  
            Enemy_list.append(enemy)
        
        # 检测鼠标点击
        mouse_left, mouse_middle, mouse_right = pygame.mouse.get_pressed() 
        if player.health > 0:
            if mouse_left:
                player.fire(camera_group)
        if mouse_right:              #模拟受伤与回血
                player.take_damage(1)
        if mouse_middle:
                player.heal(1)
        
        if pause_time < no_pause_time:
            tmp_time += no_pause_time - pause_time
            pause_time = 0
            no_pause_time = 0 
        
        if elapsed_time < game_time:
            elapsed_time = time.time() - start_time - tmp_time 
            if player.health == 0 and death_time != None:
                elapsed_time = death_time
            if len(enemy_out)==enemy_number and player.health > 0 and over_time != None:
                elapsed_time = over_time
            minutes_elapsed = int(game_time - elapsed_time) // 60  
            seconds_elapsed = int(game_time - elapsed_time) % 60  
  
        text_pos = u"time: %d : %d"%(minutes_elapsed, seconds_elapsed)
        show_text(screen, (800,0), text_pos, (255,0,0), True, 40)
  
        # 检查是否超过5分钟  
        if elapsed_time >= game_time and player.health >= 0 :  # 10秒到了 
            font = pygame.font.Font(None, 48)  
            text_pos = "很可惜，时间到了"
            show_text_with_chinese_font(screen, (500, 500), text_pos, (255, 0, 0), 100)
            text_pos = "你可以按‘O’键重新开始"
            show_text_with_chinese_font(screen, (600, 600), text_pos, (0, 0, 0), 50) 
        
        # 显示文字
        if player.health == 0 and elapsed_time < game_time:     #如果飞机生命值为 0 
            #显示文字
            death_time = elapsed_time # 记录阵亡时间
            text_pos = "很遗憾，这局输了"
            show_text_with_chinese_font(screen, (500, 500), text_pos, (255, 0, 0), 100)
            text_pos = "你可以按‘O’键重新开始"
            show_text_with_chinese_font(screen, (600, 600), text_pos, (0, 0, 0), 50)   
            # paused = not paused
        
        if len(enemy_out)==enemy_number and player.health > 0 and elapsed_time < game_time:  # 如果敌机全部消灭且生命值仍大于零
            #显示文字
            over_time = elapsed_time # 记录结束时间
            text_pos = "很好！恭喜通关！"
            show_text_with_chinese_font(screen, (550, 500), text_pos, (0, 0, 0), 100) 
            text_pos = "最终得分是: %d"%(player.score)
            show_text_with_chinese_font(screen, (600, 600), text_pos, (255, 0, 0), 100) 
            text_pos = "你可以按“O”键重新开始"
            show_text_with_chinese_font(screen, (650, 700), text_pos, (0, 0, 0), 50) 
            #pygame.display.update() #更新屏幕
        
        text_pos = u"plane1   score: %d "%(player.score)
        show_text(screen, (20,0), text_pos, (255,0,0), True, 40)
        #显示飞机坐标
        text_pos = u"center:(%d,%d)"%(player.rect.centerx - camera_group.ground_rect.x, 
                                      player.rect.centery - camera_group.ground_rect.y)
        show_text(screen, (20,25), text_pos, (0,0,0), True, 40)
        #显示飞机角度
        text_pos = u"current_angle:(%f)"%(player.current_angle)
        show_text(screen, (20,50), text_pos, (0,0,0), True, 40)
        # 绘制飞机的血条  
        text_pos = u"current_health:(%d)"%(player.health)
        show_text(screen, (20,75), text_pos, (0,255,0), True, 40)
        player.health_bar.draw((255,0,0), (0,255,0), player.health) 
        #显示弹夹容量
        text_pos = u"bullet_clip:     (%d)"%(player.bullets_in_clip)
        show_text(screen, (20,100), text_pos, (255,255,0), True, 40)
        player.bullet_clip_bar.draw((0,0,0), (255,255,0), player.bullets_in_clip)
        #显示剩余弹药容量
        text_pos = u"bullet_remanent:(%d)"%(player.bullet_remanent)
        show_text(screen, (20,125), text_pos, (255,255,0), True, 40)
        player.bullet_all_bar.draw((0,0,0), (255,255,0), player.bullet_remanent)
        # 显示剩余敌机数量
        text_pos = u"remanent enemy number:(%d)"%(enemy_number-len(enemy_out))
        show_text(screen, (1350,0), text_pos, (255,0,0), True, 40)
        # 显示当前敌机数量
        text_pos = u"now enemy number:(%d)"%(len(Enemy_list))
        show_text(screen, (1350,25), text_pos, (255,0,0), True, 40)
        

        pygame.display.update()
        clock.tick(200)
        
    else:  
        # #记录暂停时刻  游戏暂停时的绘制（可选）  
        if not time_flag:
            pause_time = time.time()
            time_flag = not time_flag